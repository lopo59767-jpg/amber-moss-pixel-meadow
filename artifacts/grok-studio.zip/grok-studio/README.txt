Grok Studio

Папка с кодом сайта.

Запуск:
  npm install
  npm run dev

Откроется на http://localhost:8080
node_modules в архив не входят.
